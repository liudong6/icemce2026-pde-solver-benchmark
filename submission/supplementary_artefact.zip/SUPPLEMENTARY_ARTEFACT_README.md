# Supplementary Artefact README

## Reviewer response update — v6 / v1.2.1-reviewer-response

The current delivery is https://doi.org/10.5281/zenodo.22908710, with GitHub release https://github.com/liudong6/icemce2026-pde-solver-benchmark/releases/tag/v1.2.1-reviewer-response. It adds the revised two-page author-to-reviewer response and matching Markdown source. The paper and scientific evidence are unchanged from v5 (https://doi.org/10.5281/zenodo.22874266); existing manuscript and response citations to that evidence remain intentional. See RELEASE_NOTES.md for the scope and archive contents.

Submission formatting (21 September): the primary manuscript DOCX and its PDF export highlight additions and replacements relative to the previous reviewed manuscript in yellow. The LaTeX source/PDF is an unhighlighted backup. Regenerating the Word manuscript preserves highlighting using tools/review_baseline.docx and tools/highlight_manuscript_changes.py.

## Second-round review revision — v5 / v1.2

This complete revision is identified by Zenodo v5, https://doi.org/10.5281/zenodo.22874266, and GitHub release https://github.com/liudong6/icemce2026-pde-solver-benchmark/releases/tag/v1.2-icemce2026-review-revision. The v4 DOI identifies the earlier baseline and controlled extension. This revision adds 378 paired callback-calibration solves, the complete nine-cell face-averaging table in the main paper, an explicit interface-resistance interpretation, and distinct scopes for historical, extension and calibration timings. Original raw files are unchanged. The primary Word/PDF manuscript highlights review changes in yellow.

Reproduce the new tables without rerunning timings:

```powershell
python experiments/analyze_protocol_sensitivity.py
```

The prospective design is `experiments/protocol_sensitivity.md`; raw timings, configuration, source hashes and environment are in `results/raw/protocol_sensitivity`. Method quartiles, paired ratios, winner votes and the numerical audit are in `results/analysis/protocol_sensitivity`. To rerun measurements, use `python experiments/run_protocol_sensitivity.py --output results/raw/protocol_sensitivity_rerun` in an unused directory, with no other performance workload running. Existing evidence is never overwritten.

All 378 recorded residuals are at most 1e-8, and all 189 mode pairs have identical solution hashes and iteration counts. Median solve-time inflation is 1.54–1.84 for CG, 1.58–1.77 for Jacobi, and 1.03–1.06 for AMG. The nine median winners agree between callbacks, but vote instability is retained. These results do not reconstruct historical cold-import/thread/order effects or establish a machine-independent crossover.


This package supports the ICEMCE 2026 manuscript:

`A Coefficient-Aware Finite-Difference Benchmark for Solver Selection and CPU/GPU Stencil Scaling in Heat-Conduction Simulation`

The previously published baseline and controlled extension are archived on Zenodo at https://doi.org/10.5281/zenodo.22668106 (v4) and corresponds to GitHub release v1.1-icemce2026-submission. Baseline benchmark data remain available at https://doi.org/10.5281/zenodo.22303525. This package adds matched-field, source, translation, perturbation and portfolio experiments and contains the revised manuscript. File hashes are listed in `MANIFEST.sha256`.

## Contents

- `src/pdescale/`: finite-difference operator, face-averaging checks, coefficient-field descriptors, conditioning estimates, descriptor-to-solver analysis, solver decision logic, timing-stability summaries, manufactured-solution problems, solvers, CPU scaling kernels, CUDA stencil kernels, plotting, and metadata utilities.
- `experiments/`: command-line entry points for convergence, solver comparison, coefficient-aware solver decision maps, conditioning estimates, discontinuous-interface verification, arithmetic/harmonic sensitivity analysis, descriptor-to-solver rank analysis, repeated solver timing, CPU scaling, CUDA scaling, hardware crossover fitting, table generation, and figure regeneration.
- `experiments/cases/`: YAML experiment configurations.
- `tests/`: pytest checks for operators, manufactured solutions, solvers, kernels, scaling summaries, and plotting.
- `results/raw/`: raw CSV files and environment metadata used to support reported results.
- `results/figures/`: generated figures.
- `results/figures/solver_decision_map.png`: supplementary heatmap; the main manuscript reports the same selections in its decision-count table.
- `paper/tables/`: manuscript table sources.
- `requirements.txt` and `requirements-cuda.txt`: CPU and CUDA Python dependencies.
- `paper/icemce2026_iop_manuscript.docx` and `.pdf`: primary manuscript and render; `paper/main.tex`, `.pdf`, and `references.bib`: LaTeX backup.
- `tools/build_iop_docx.py`, `tools/export_iop_pdf.ps1`, and `template/`: document generation; see the root README for additional document-tool dependencies.

## Controlled extension

The extension's raw CSV and configuration records are under `results/raw/counterfactual`, with complete summary tables under `results/analysis/counterfactual`. The portable experiment scripts and detailed protocol are in `experiments/counterfactual`. The 576 pilot, 1440 confirmation, 640 independent-family and 132 perturbation solves are retained as separate datasets. Pilot failures and unstable timing winners are included. The main figure and all extension summaries are regenerated by:

```powershell
python experiments/analyze_counterfactual.py
```

See `experiments/counterfactual/README.md` before rerunning timings. In particular, follow-ups use count-only callbacks, warm imports, fixed recorded setup seeds, one BLAS thread and an independent residual check; historical monitored timings are a separate protocol. The primary manuscript reports exact counterexamples and bounded measurements, not a predictive solver or a universal performance claim.

## Reproduction Commands

Virtual environments are not distributed with this package. Run from the package root after creating one and installing the locked dependencies:

```powershell
py -3.12 -m venv .venv-cuda
.\.venv-cuda\Scripts\python.exe -m pip install --upgrade pip
.\.venv-cuda\Scripts\python.exe -m pip install -r requirements-cuda.txt
.\.venv-cuda\Scripts\python.exe -m pip install -e .
```

For a CPU-only check, install `requirements.txt` instead of `requirements-cuda.txt` and skip `run_gpu_stencil.py`.

The conditioning script includes `N=128` spectral estimates and took under one minute on the author machine; the face-averaging sensitivity script took about two minutes, and the repeated timing script uses five repeats for representative solver decisions and took about two minutes. For a quick smoke check, regenerate tables and figures from the included raw CSV files first, then rerun the conditioning, interface, sensitivity, and timing scripts when validating the full evidence chain.

```powershell
.\.venv-cuda\Scripts\python.exe -m pytest -q
.\.venv-cuda\Scripts\python.exe experiments\run_convergence.py
.\.venv-cuda\Scripts\python.exe experiments\run_solvers.py
.\.venv-cuda\Scripts\python.exe experiments\run_decision_map.py
.\.venv-cuda\Scripts\python.exe experiments\run_conditioning.py
.\.venv-cuda\Scripts\python.exe experiments\run_interface_verification.py
.\.venv-cuda\Scripts\python.exe experiments\analyze_difficulty_relationships.py
.\.venv-cuda\Scripts\python.exe experiments\run_averaging_sensitivity.py
.\.venv-cuda\Scripts\python.exe experiments\run_timing_stability.py
.\.venv-cuda\Scripts\python.exe experiments\run_scaling.py
.\.venv-cuda\Scripts\python.exe experiments\run_gpu_stencil.py
.\.venv-cuda\Scripts\python.exe experiments\fit_hardware_crossover.py
.\.venv-cuda\Scripts\python.exe -m pdescale.metadata --output results\raw\environment.json
.\.venv-cuda\Scripts\python.exe experiments\make_paper_tables.py
.\.venv-cuda\Scripts\python.exe experiments\make_all_figures.py --only all
```

If CUDA is unavailable, the CPU convergence, solver, and CPU scaling experiments remain reproducible; the CUDA crossover rows require an NVIDIA GPU and a working Numba-CUDA stack.

## Evidence Map

- `results/raw/convergence.csv`: manufactured-solution convergence rates and residuals.
- `results/raw/solver_benchmark.csv`: CG, Jacobi-PCG, and AMG-PCG iteration counts, residuals, setup time, solve time, total time, and memory estimate.
- `results/raw/solver_decision_map.csv`: coefficient-family decision grid with fastest converged solver labels.
- `results/raw/conditioning.csv`: spectral condition-number estimates for `N=32`, `N=64`, and `N=128`.
- `results/raw/interface_verification.csv`: one-dimensional two-material jump-interface verification for arithmetic and harmonic face averaging.
- `results/raw/difficulty_relationships.csv`: Spearman rank correlations linking coefficient descriptors to solver behaviour, including pooled all-grid rows, fixed-`N` strata, raw stratum coefficients, deterministic fixed-grid case-resampling intervals, and diagnostic 4999-permutation p-values. Condition numbers are matched to `N=64` and `N=128` where available; the `N=128` estimate is used as the maximum-available proxy for `N=256`.
- `results/raw/averaging_sensitivity.csv`: arithmetic/harmonic face-averaging sensitivity for discontinuous `C_k=100` stress cases.
- `results/raw/timing_repeats.csv`: raw repeated timing rows for representative solver-decision cases.
- `results/raw/timing_stability.csv`: median-best solver, vote fraction, speedup, and relative-IQR summary for repeated timings.
- `results/raw/cpu_scaling.csv`: NumPy, Numba serial, and Numba parallel stencil timings and estimated bandwidth.
- `results/raw/gpu_stencil.csv`: CPU and CUDA Jacobi kernel timings, estimated bandwidth, numerical agreement, and kernel-only speedup.
- `results/raw/hardware_crossover_model.csv`: exploratory four-point CPU/CUDA fit. Its CPU prediction is negative at `N=512`, so its intersection is not a validated crossover threshold.
- `results/raw/environment.json`: Python, package, CPU, memory, platform, and CUDA metadata.
- `paper/tables/*.tex`: manuscript tables regenerated from the raw CSV files.
- `paper/tables/timing_stability_summary.tex`: all 15 existing repeated-timing case-size cells, each with five repeats; the main manuscript includes all rows.
- `paper/tables/hardware_model_summary.tex`: supplementary exploratory fit table, excluded from the main manuscript because its intersection is not a validated threshold.
- `cold_start_smoke_log.txt`: clean-extraction smoke-check log for table and figure regeneration from the packaged artefact.

## Stencil-Bandwidth Convention

The variable-coefficient stencil bandwidth estimate uses 11 double-precision values per interior point, or 88 bytes per point. The Jacobi crossover estimate uses five double-precision values per interior point, or 40 bytes per point. These are operational byte models for within-paper comparison, not hardware peak-bandwidth measurements.

## Scope Limits

The solver comparison is retrospective: its winning time excludes the expense of evaluating the other candidates. The same class wins across all coefficient fields within each tested resolution, so these results do not establish predictive value for a coefficient-driven selector. For constant conductivity, Jacobi is a scalar rescaling and does not improve the spectral condition number.

PyAMG spectral-estimation random starts were not fixed; historical BLAS thread settings and processor power states were not recorded. The archived timings and hierarchy-dependent iteration counts are observations of those runs, not exact-value guarantees for reruns. CPU/CUDA stencil rows are within-run averages, not independent replicated timing estimates.

Solver timings include true-residual recomputation at every iteration, including its extra sparse matrix-vector product and norm evaluations. Matrix assembly and right-hand-side construction are excluded. Methods run in a fixed order; the first AMG setup in a fresh process includes the PyAMG import. The selections and speedups apply to this monitored implementation. CUDA timings include host launch and final synchronisation overhead for resident-data batches and exclude allocation, compilation warm-up, and transfers.

The artefact does not claim industrial geometry support, unstructured finite elements, end-to-end GPU sparse-solver acceleration, general GPU superiority at all grid sizes, or a universal single coefficient-difficulty predictor.

The manuscript currently cites the published DOI specifically for the unchanged benchmark data. When this revision is published, cite the new version DOI for the revised artefact and retain the version chain at https://doi.org/10.5281/zenodo.22290959.


The candidate-solver sensitivity extension adds 744 accepted solves, including a 504-solve interleaved confirmation with classical AMG. Rebuild its summaries with `python experiments/analyze_portfolio.py`. See `experiments/counterfactual/README.md` for settings, timing boundaries, portfolio-dependent cost floors, and safe rerun instructions. These data are included in the revised artefact at https://doi.org/10.5281/zenodo.22668106; the earlier baseline DOI identifies the retained baseline measurements only.


## CPU-only and required-CUDA test modes

After installing `requirements.txt`, run `python -m pytest -q -rs`. Tests that
require the optional CUDA runtime/device are explicitly skipped when CUDA is
unavailable; all CPU, numerical, data-analysis and metadata tests still run.
To validate a CUDA installation, run `python -m pytest -q --require-cuda`.
This mode fails when CUDA is unavailable, so a GPU validation run cannot pass
by silently skipping its GPU tests. The five CUDA-dependent tests carry the
`cuda` marker and can also be selected with `-m cuda --require-cuda`.

The optional `requirements-cpu-verified.txt` pins the resolved CPU dependency
set, including transitive dependencies, for Windows x86-64/Python3.12.
Install it instead of `requirements.txt` when reproducing that exact CPU
dependency set. Install the extracted project itself with `pip install -e .`.
Document export and CUDA use their separately described runtimes.

The fresh CPU environment check passed 91 tests with 5 explicit CUDA skips and reproduced 76 recorded/generated outputs byte-for-byte. The existing CUDA environment passed all 96 tests with `--require-cuda`. Dependency versions and the scope of this check are recorded in `results/raw/counterfactual/reproduction_environment.json`; the package smoke log records the commands.

`paper/EVIDENCE_MAP.md` maps main text results, tables and figures to recorded inputs and regeneration commands. The main manuscript presents all 12 interleaved translated pairs and explicitly defines the portfolio-conditional cost floor. Complete face-averaging and baseline timing-stability tables remain in `paper/tables/` as supplementary evidence.
